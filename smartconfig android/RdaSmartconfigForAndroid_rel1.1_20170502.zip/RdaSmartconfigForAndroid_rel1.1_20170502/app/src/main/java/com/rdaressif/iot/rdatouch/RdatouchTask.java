package com.rdaressif.iot.rdatouch;

import java.util.List;

import android.content.Context;

import com.rdaressif.iot.rdatouch.task.RdatouchTaskParameter;
import com.rdaressif.iot.rdatouch.task.IRdatouchTaskParameter;
import com.rdaressif.iot.rdatouch.task.__RdatouchTask;

public class RdatouchTask implements IRdatouchTask {

	public __RdatouchTask _mRdatouchTask;
	private IRdatouchTaskParameter _mParameter;

	/**
	 * Constructor of RdatouchTask
	 * 
	 * @param apSsid
	 *            the Ap's ssid
	 * @param apBssid
	 *            the Ap's bssid
	 * @param apPassword
	 *            the Ap's password
	 * @param isSsidHidden
	 *            whether the Ap's ssid is hidden
	 * @param context
	 *            the Context of the Application
	 */
	public RdatouchTask(String apSsid, String apBssid, String apPassword,
			boolean isSsidHidden, Context context) {
		_mParameter = new RdatouchTaskParameter();
		_mRdatouchTask = new __RdatouchTask(apSsid, apBssid, apPassword,
				context, _mParameter, isSsidHidden);
	}

	/**
	 * Constructor of RdatouchTask
	 * 
	 * @param apSsid
	 *            the Ap's ssid
	 * @param apBssid
	 *            the Ap's bssid
	 * @param apPassword
	 *            the Ap's password
	 * @param isSsidHidden
	 *            whether the Ap's ssid is hidden
	 * @param timeoutMillisecond
	 *            (it should be >= 15000+6000) millisecond of total timeout
	 * @param context
	 *            the Context of the Application
	 */
	public RdatouchTask(String apSsid, String apBssid, String apPassword,
			boolean isSsidHidden, int timeoutMillisecond, Context context) {
		_mParameter = new RdatouchTaskParameter();
		_mParameter.setWaitUdpTotalMillisecond(timeoutMillisecond);
		_mRdatouchTask = new __RdatouchTask(apSsid, apBssid, apPassword,
				context, _mParameter, isSsidHidden);
	}

	@Override
	public void interrupt() {
		_mRdatouchTask.interrupt();
	}

	@Override
	public IRdatouchResult executeForResult() throws RuntimeException {
		return _mRdatouchTask.executeForResult();
	}

	@Override
	public boolean isCancelled() {
		return _mRdatouchTask.isCancelled();
	}

	@Override
	public List<IRdatouchResult> executeForResults(int expectTaskResultCount)
			throws RuntimeException {
		if (expectTaskResultCount <= 0) {
			expectTaskResultCount = Integer.MAX_VALUE;
		}
		return _mRdatouchTask.executeForResults(expectTaskResultCount);
	}

	@Override
	public void setRdatouchListener(IRdatouchListener rdatouchListener) {
		_mRdatouchTask.setRdatouchListener(rdatouchListener);
	}
}
