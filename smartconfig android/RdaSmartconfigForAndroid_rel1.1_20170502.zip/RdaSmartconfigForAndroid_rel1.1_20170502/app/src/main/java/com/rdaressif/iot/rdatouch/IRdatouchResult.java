package com.rdaressif.iot.rdatouch;

import java.net.InetAddress;

public interface IRdatouchResult {
	
	/**
	 * check whether the rdatouch task is executed suc
	 * 
	 * @return whether the rdatouch task is executed suc
	 */
	boolean isSuc();

	/**
	 * get the device's bssid
	 * 
	 * @return the device's bssid
	 */
	String getBssid();

	/**
	 * check whether the rdatouch task is cancelled by user
	 * 
	 * @return whether the rdatouch task is cancelled by user
	 */
	boolean isCancelled();

	/**
	 * get the ip address of the device
	 * 
	 * @return the ip device of the device
	 */
	InetAddress getInetAddress();
}
