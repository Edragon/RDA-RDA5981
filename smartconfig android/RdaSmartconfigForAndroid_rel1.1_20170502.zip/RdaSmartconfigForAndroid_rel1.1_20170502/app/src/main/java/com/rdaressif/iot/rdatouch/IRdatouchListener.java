package com.rdaressif.iot.rdatouch;

public interface IRdatouchListener {
	/**
	 * when new rdatouch result is added, the listener will call
	 * onRdatouchResultAdded callback
	 * 
	 * @param result
	 *            the Rdatouch result
	 */
	void onRdatouchResultAdded(IRdatouchResult result);
}
