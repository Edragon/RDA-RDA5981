package com.rdaressif.iot.rdatouch.task;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import com.rdaressif.iot.rdatouch.RdatouchResult;
import com.rdaressif.iot.rdatouch.IRdatouchListener;
import com.rdaressif.iot.rdatouch.IRdatouchResult;
import com.rdaressif.iot.rdatouch.protocol.RdatouchGenerator;
import com.rdaressif.iot.rdatouch.udp.UDPSocketClient;
import com.rdaressif.iot.rdatouch.udp.UDPSocketServer;
import com.rdaressif.iot.rdatouch.util.ByteUtil;
import com.rdaressif.iot.rdatouch.util.RdaNetUtil;

import android.content.Context;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

public class __RdatouchTask implements __IRdatouchTask {

	/**
	 * one indivisible data contain 3 9bits info
	 */
	private static final int ONE_DATA_LEN = 3;

	private static final String TAG = "RdatouchTask";

	private volatile List<IRdatouchResult> mRdatouchResultList;
	private volatile boolean mIsSuc = false;
	private volatile boolean mIsInterrupt = false;
	private volatile boolean mIsExecuted = false;
	private final UDPSocketClient mSocketClient;
	private final UDPSocketServer mSocketServer;
	private TcpSocketServer mResultServer;
	private final String mApSsid;
	private final String mApBssid;
	private final boolean mIsSsidHidden;
	private final String mApPassword;
	private final Context mContext;
	private AtomicBoolean mIsCancelled;
	private IRdatouchTaskParameter mParameter;
	private volatile Map<String, Integer> mBssidTaskSucCountMap;
	private IRdatouchListener mRdatouchListener;
	private Thread mTask;

	private class TcpSocketServer {
	    private static final int MAX_RESULT_LEN = 64;
	    private ServerSocket mServerSocket;
	    private Socket mClient;
	    private int mExpectedResultLen;
	    public TcpSocketServer(int port, int expectedResultLen) {
	        if (expectedResultLen > MAX_RESULT_LEN || expectedResultLen < 0) {
	            throw new IllegalArgumentException("illegal expected result length:" + expectedResultLen);
	        }
	        try {
	            mServerSocket = new ServerSocket(port);
	        } catch (IOException ex) {
	            throw new RuntimeException(ex);
	        }
	        mExpectedResultLen = expectedResultLen;
	    }

	    private void lisenClient(int totalTimeout) throws IOException {
	        long start = SystemClock.uptimeMillis();
	        int elapse = 0;
	        int left = 0;
	        byte[] buffer = new byte[MAX_RESULT_LEN];
	        while(true) {
	            left = totalTimeout - elapse;
	            if (left <= 0) {
	                break;
	            }
	            mServerSocket.setSoTimeout(left);
	            try {
	                mClient = mServerSocket.accept();
	            } catch (SocketTimeoutException ex) {
	                Log.d(TAG, "TcpSocketServer accept timeout");
	                break;
	            }

	            if (mClient != null) {
	                elapse = (int) (SystemClock.uptimeMillis() - start);
	                left = totalTimeout - elapse;
	                if (left <= 0) {
	                    left = 0;
	                }
	                try {
	                    mClient.setSoTimeout(left);
	                    InputStream is = mClient.getInputStream();
	                    int ret = is.read(buffer);
	                    if (ret == mExpectedResultLen) {
	                        onReceiveExpectedData(buffer, mExpectedResultLen);
	                    } else {
	                        Log.d(TAG, "receive result is not unexpected, receive:" + ret + " expected:" + mExpectedResultLen);
	                    }
	                } catch (SocketTimeoutException ex) {
	                    Log.d(TAG, "TcpSocketServer read client timeout");
	                } catch (IOException ex) {
	                    Log.d(TAG, "IOException:", ex);
	                } finally {
	                    try {
	                        mClient.close();
	                    } catch (IOException ex) {
	                        Log.d(TAG, "fail to  close client socket");
	                    }
	                    mClient = null;
	                }
	            }

                elapse = (int) (SystemClock.uptimeMillis() - start);
                if (mServerSocket == null) {
                    break;
                }
	        }
	        if (mServerSocket != null) {
	            mServerSocket.close();
	        }
	    }

	    public void onReceiveExpectedData(byte[] buffer, int len) {
	        int resultOne = buffer[0];
	        int expectedResultOne = getExpectedResultOne();
	        if (resultOne == expectedResultOne) {
	            Log.d(TAG, "receive correct result");
	            try {
                    String bssid = ByteUtil.parseBssid(buffer,
                            mParameter.getRdatouchResultOneLen(),
                            mParameter.getRdatouchResultMacLen());
                    InetAddress inetAddress = RdaNetUtil.parseInetAddr(buffer,
                                    mParameter.getRdatouchResultOneLen() + mParameter.getRdatouchResultMacLen(),
                                    mParameter.getRdatouchResultIpLen());
                    __putRdatouchResult(true, bssid, inetAddress);
	            } catch (Exception ex) {
	                Log.d(TAG, "Parse result data fail", ex);
	            }
	        } else {
	            Log.d(TAG, "receive wrong result one, resultOne:" + resultOne + " expectedResultOne:" + expectedResultOne);
	        }
	        if (mRdatouchResultList.size() == mParameter.getExpectTaskResultCount()) {
	            interrupt();
	        }
	    }

	    public void startListenAsync(final int totalTimeout) {
	        mTask = new Thread() {
	            @Override
	            public void run() {
	                super.run();
	                long start = SystemClock.uptimeMillis();
	                long elapse = 0;
	                while (true) {
	                    int left = (int)(totalTimeout - elapse);
	                    if (left <= 0) {
	                        break;
	                    }
	                    if (mServerSocket == null) {
	                        break;
	                    }
                        try {
                            lisenClient(left);
                        } catch (IOException ex) {
                            Log.d(TAG, "lisenClient IOException error:" + ex.getMessage(), ex);
                        }
                        elapse = SystemClock.uptimeMillis() - start;
                        if (elapse < totalTimeout) {
                            Log.d(TAG, "Timeout is not reach, retry it");
                        }
	                }
	            }
	        };
	        mTask.start();
	    }

	    public void close() {
	        if (mServerSocket != null) {
	            try {
	                if (mClient != null) {
	                    mClient.close();
	                }
	                mServerSocket.close();
	                mServerSocket = null;
	            } catch (IOException ex) {
	                Log.d(TAG, "fail to close socket" + ex.getMessage(), ex);
	            }
	        }
	    }
	}

	private int getExpectedResultOne() {
	    byte[] apSsidAndPassword = ByteUtil.getBytesByString(mApSsid
                + mApPassword);
        byte expectOneByte = (byte) (apSsidAndPassword.length + 9);
        return expectOneByte;
	}
	public __RdatouchTask(String apSsid, String apBssid, String apPassword,
			Context context, IRdatouchTaskParameter parameter,
			boolean isSsidHidden) {
		if (TextUtils.isEmpty(apSsid)) {
			throw new IllegalArgumentException(
					"the apSsid should be null or empty");
		}
		if (apPassword == null) {
			apPassword = "";
		}
		mContext = context;
		mApSsid = apSsid;
		mApBssid = apBssid;
		mApPassword = apPassword;
		mIsCancelled = new AtomicBoolean(false);
		mSocketClient = new UDPSocketClient();
		mParameter = parameter;
		mSocketServer = new UDPSocketServer(mParameter.getPortListening(),
				mParameter.getWaitUdpTotalMillisecond(), context);
		mIsSsidHidden = isSsidHidden;
		mRdatouchResultList = new ArrayList<IRdatouchResult>();
		mBssidTaskSucCountMap = new HashMap<String, Integer>();
		mResultServer = new TcpSocketServer(mParameter.getPortListening(),
		        mParameter.getRdatouchResultTotalLen());
	}

	private void __putRdatouchResult(boolean isSuc, String bssid,
			InetAddress inetAddress) {
		synchronized (mRdatouchResultList) {
			// check whether the result receive enough UDP rrdaonse
			boolean isTaskSucCountEnough = false;
			Integer count = mBssidTaskSucCountMap.get(bssid);
			if (count == null) {
				count = 0;
			}
			++count;
			if (__IRdatouchTask.DEBUG) {
				Log.d(TAG, "__putRdatouchResult(): count = " + count);
			}
			mBssidTaskSucCountMap.put(bssid, count);
			isTaskSucCountEnough = count >= mParameter
					.getThresholdSucBroadcastCount();
			if (!isTaskSucCountEnough) {
				if (__IRdatouchTask.DEBUG) {
					Log.d(TAG, "__putRdatouchResult(): count = " + count
							+ ", isn't enough");
				}
				return;
			}
			// check whether the result is in the mRdatouchResultList already
			boolean isExist = false;
			for (IRdatouchResult rdatouchResultInList : mRdatouchResultList) {
				if (rdatouchResultInList.getBssid().equals(bssid)) {
					isExist = true;
					break;
				}
			}
			// only add the result who isn't in the mRdatouchResultList
			if (!isExist) {
				if (__IRdatouchTask.DEBUG) {
					Log.d(TAG, "__putRdatouchResult(): put one more result");
				}
				final IRdatouchResult rdatouchResult = new RdatouchResult(isSuc,
						bssid, inetAddress);
				mRdatouchResultList.add(rdatouchResult);
				if (mRdatouchListener != null) {
					mRdatouchListener.onRdatouchResultAdded(rdatouchResult);
				}
			}
		}
	}

	private List<IRdatouchResult> __getRdatouchResultList() {
		synchronized (mRdatouchResultList) {
			if (mRdatouchResultList.isEmpty()) {
				RdatouchResult rdatouchResultFail = new RdatouchResult(false,
						null, null);
				rdatouchResultFail.setIsCancelled(mIsCancelled.get());
				mRdatouchResultList.add(rdatouchResultFail);
			}
			
			return mRdatouchResultList;
		}
	}

	private synchronized void __interrupt() {
		if (!mIsInterrupt) {
			mIsInterrupt = true;
			mSocketClient.interrupt();
			mSocketServer.interrupt();
			mResultServer.close();
			// interrupt the current Thread which is used to wait for udp rrdaonse
			if (mTask != null) {
				mTask.interrupt();
				mTask = null;
			}
		}
	}

	@Override
	public void interrupt() {
		if (__IRdatouchTask.DEBUG) {
			Log.d(TAG, "interrupt()");
		}
		mIsCancelled.set(true);
		__interrupt();
	}

	private void __listenAsyn(final int expectDataLen) {
		mTask = new Thread() {
			public void run() {
				if (__IRdatouchTask.DEBUG) {
					Log.d(TAG, "__listenAsyn() start");
				}
				long startTimestamp = System.currentTimeMillis();
				byte[] apSsidAndPassword = ByteUtil.getBytesByString(mApSsid
						+ mApPassword);
				byte expectOneByte = (byte) (apSsidAndPassword.length + 9);
				if (__IRdatouchTask.DEBUG) {
					Log.i(TAG, "expectOneByte: " + (0 + expectOneByte));
				}
				byte receiveOneByte = -1;
				byte[] receiveBytes = null;
				while (mRdatouchResultList.size() < mParameter
						.getExpectTaskResultCount() && !mIsInterrupt) {
					receiveBytes = mSocketServer
							.receiveSpecLenBytes(expectDataLen);
					if (receiveBytes != null) {
						receiveOneByte = receiveBytes[0];
					} else {
						receiveOneByte = -1;
					}
					if (receiveOneByte == expectOneByte) {
						if (__IRdatouchTask.DEBUG) {
							Log.e(TAG, "receive correct broadcast");
						}
						// change the socket's timeout
						long consume = System.currentTimeMillis()
								- startTimestamp;
						int timeout = (int) (mParameter
								.getWaitUdpTotalMillisecond() - consume);
						if (timeout < 0) {
							if (__IRdatouchTask.DEBUG) {
								Log.i(TAG, "rdatouch timeout");
							}
							break;
						} else {
							if (__IRdatouchTask.DEBUG) {
								Log.i(TAG, "mSocketServer's new timeout is "
										+ timeout + " milliseconds");
							}
							mSocketServer.setSoTimeout(timeout);
							if (__IRdatouchTask.DEBUG) {
								Log.i(TAG, "receive correct broadcast");
							}
							if (receiveBytes != null) {
								String bssid = ByteUtil.parseBssid(
										receiveBytes,
										mParameter.getRdatouchResultOneLen(),
										mParameter.getRdatouchResultMacLen());
								InetAddress inetAddress = RdaNetUtil
										.parseInetAddr(
												receiveBytes,
												mParameter
														.getRdatouchResultOneLen()
														+ mParameter
																.getRdatouchResultMacLen(),
												mParameter
														.getRdatouchResultIpLen());
								__putRdatouchResult(true, bssid, inetAddress);
							}
						}
					} else {
						if (__IRdatouchTask.DEBUG) {
							Log.e(TAG, "receive rubbish message, just ignore");
						}
					}
				}
				mIsSuc = mRdatouchResultList.size() >= mParameter
						.getExpectTaskResultCount();
				__RdatouchTask.this.__interrupt();
				if (__IRdatouchTask.DEBUG) {
					Log.d(TAG, "__listenAsyn() finish");
				}
			}
		};
		mTask.start();
	}

	private boolean __execute(IRdatouchGenerator generator) {

		long startTime = System.currentTimeMillis();
		long currentTime = startTime;
		long lastTime = currentTime - mParameter.getTimeoutTotalCodeMillisecond();

		byte[][] gcBytes2 = generator.getGCBytes2();
		byte[][] dcBytes2 = generator.getDCBytes2();

		int index = 0;
		while (!mIsInterrupt) {
			if (currentTime - lastTime >= mParameter.getTimeoutTotalCodeMillisecond()) {
				if (__IRdatouchTask.DEBUG) {
					Log.d(TAG, "send gc code ");
				}
				// send guide code
				while (!mIsInterrupt
						&& System.currentTimeMillis() - currentTime < mParameter
								.getTimeoutGuideCodeMillisecond()) {
					mSocketClient.sendData(gcBytes2,
							mParameter.getTargetHostname(),
							mParameter.getTargetPort(),
							mParameter.getIntervalGuideCodeMillisecond());
					// check whether the udp is send enough time
					if (System.currentTimeMillis() - startTime > mParameter.getWaitUdpSendingMillisecond()) {
						break;
					}
				}
				lastTime = currentTime;
			} else {
				mSocketClient.sendData(dcBytes2, index, ONE_DATA_LEN,
						mParameter.getTargetHostname(),
						mParameter.getTargetPort(),
						mParameter.getIntervalDataCodeMillisecond());
				index = (index + ONE_DATA_LEN) % dcBytes2.length;
			}
			currentTime = System.currentTimeMillis();
			// check whether the udp is send enough time
			if (currentTime - startTime > mParameter.getWaitUdpSendingMillisecond()) {
				break;
			}
		}

		return mIsSuc;
	}

	private void __checkTaskValid() {
		// !!!NOTE: the rdatouch task could be executed only once
		if (this.mIsExecuted) {
			throw new IllegalStateException(
					"the Rdatouch task could be executed only once");
		}
		this.mIsExecuted = true;
	}

	@Override
	public IRdatouchResult executeForResult() throws RuntimeException {
		return executeForResults(1).get(0);
	}

	@Override
	public boolean isCancelled() {
		return this.mIsCancelled.get();
	}

	@Override
	public List<IRdatouchResult> executeForResults(int expectTaskResultCount)
			throws RuntimeException {
		__checkTaskValid();

		mParameter.setExpectTaskResultCount(expectTaskResultCount);

		if (__IRdatouchTask.DEBUG) {
			Log.d(TAG, "execute()");
		}
		if (Looper.myLooper() == Looper.getMainLooper()) {
			throw new RuntimeException(
					"Don't call the rdatouch Task at Main(UI) thread directly.");
		}
		InetAddress localInetAddress = RdaNetUtil.getLocalInetAddress(mContext);
		if (__IRdatouchTask.DEBUG) {
			Log.i(TAG, "localInetAddress: " + localInetAddress);
		}
		// generator the rdatouch byte[][] to be transformed, which will cost
		// some time(maybe a bit much)
		IRdatouchGenerator generator = new RdatouchGenerator(mApSsid, mApBssid,
				mApPassword, localInetAddress, mIsSsidHidden);
		// listen the rdatouch result asyn
		//__listenAsyn(mParameter.getRdatouchResultTotalLen());
		mResultServer.startListenAsync(mParameter.getWaitUdpTotalMillisecond());
		boolean isSuc = false;
		for (int i = 0; i < mParameter.getTotalRepeatTime(); i++) {
			isSuc = __execute(generator);
			if (isSuc) {
				return __getRdatouchResultList();
			}
		}

		if (!mIsInterrupt) {
			// wait the udp rrdaonse without sending udp broadcast
			try {
				Thread.sleep(mParameter.getWaitUdpReceivingMillisecond());
			} catch (InterruptedException e) {
				// receive the udp broadcast or the user interrupt the task
				if (this.mIsSuc) {
					return __getRdatouchResultList();
				} else {
					this.__interrupt();
					return __getRdatouchResultList();
				}
			}
			this.__interrupt();
		}
		
		return __getRdatouchResultList();
	}

	@Override
	public void setRdatouchListener(IRdatouchListener rdatouchListener) {
		mRdatouchListener = rdatouchListener;
	}

}
