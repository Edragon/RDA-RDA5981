package com.rdaressif.iot.rdatouch.task;

import java.util.List;

import com.rdaressif.iot.rdatouch.IRdatouchListener;
import com.rdaressif.iot.rdatouch.IRdatouchResult;

/**
 * IRdatouchTask defined the task of rdatouch should offer. INTERVAL here means
 * the milliseconds of interval of the step. REPEAT here means the repeat times
 * of the step.
 * 
 * @author afunx
 * 
 */
public interface __IRdatouchTask {

	/**
	 * set the rdatouch listener, when one device is connected to the Ap, it will be called back
	 * @param rdatouchListener when one device is connected to the Ap, it will be called back
	 */
	void setRdatouchListener(IRdatouchListener rdatouchListener);
	
	/**
	 * Interrupt the Rdatouch Task when User tap back or close the Application.
	 */
	void interrupt();

	/**
	 * Note: !!!Don't call the task at UI Main Thread or RuntimeException will
	 * be thrown Execute the Rdatouch Task and return the result
	 * 
	 * @return the IRdatouchResult
	 * @throws RuntimeException
	 */
	IRdatouchResult executeForResult() throws RuntimeException;

	/**
	 * Note: !!!Don't call the task at UI Main Thread or RuntimeException will
	 * be thrown Execute the Rdatouch Task and return the result
	 * 
	 * @param expectTaskResultCount
	 *            the expect result count(if expectTaskResultCount <= 0,
	 *            expectTaskResultCount = Integer.MAX_VALUE)
	 * @return the list of IRdatouchResult
	 * @throws RuntimeException
	 */
	List<IRdatouchResult> executeForResults(int expectTaskResultCount) throws RuntimeException;
	
	/**
	 * Turn on or off the log.
	 */
	static final boolean DEBUG = true;

	boolean isCancelled();
}
