/** Automatically generated file. DO NOT MODIFY */
package com.rdaressif.iot_rdatouch_demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}